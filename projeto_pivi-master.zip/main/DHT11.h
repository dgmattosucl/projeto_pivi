class DHT11
{
  public:   
    DHT11(){}

  double TemperaturaAmbiente(){
    return 27;
  }

  double Umidade(){
    return 10;
  }
  
  private: 
};
